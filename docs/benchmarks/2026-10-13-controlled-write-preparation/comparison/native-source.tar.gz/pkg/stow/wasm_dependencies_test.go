package stow_test

import (
	"os"
	"os/exec"
	"strings"
	"testing"
)

func TestWasmExcludesNativeFilesystemDependencies(t *testing.T) {
	cmd := exec.Command("go", "list", "-deps", "../../cmd/stow-wasm")
	cmd.Env = append(os.Environ(), "GOOS=js", "GOARCH=wasm")
	output, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("list WASM dependencies: %v\n%s", err, output)
	}
	for _, dependency := range strings.Fields(string(output)) {
		if strings.HasSuffix(dependency, "/internal/storage/fs") ||
			strings.HasPrefix(dependency, "google.golang.org/protobuf/") {
			t.Errorf("WASM includes native object-record dependency %q", dependency)
		}
	}
}
