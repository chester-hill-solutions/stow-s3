package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/chester-hill-solutions/stow-s3/pkg/stow"
)

type workspaceResult struct {
	Version          int                       `json:"version"`
	WorkspaceID      string                    `json:"workspace_id"`
	Root             string                    `json:"root"`
	WorkingDirectory string                    `json:"working_directory"`
	Bucket           string                    `json:"bucket"`
	CheckpointID     string                    `json:"checkpoint_id,omitempty"`
	RegistryDir      string                    `json:"registry_dir,omitempty"`
	Team             string                    `json:"team,omitempty"`
	SeededBytes      int64                     `json:"seeded_bytes,omitempty"`
	SeededObjects    int64                     `json:"seeded_objects,omitempty"`
	BaseIdentity     string                    `json:"base_identity,omitempty"`
	Repositories     []stow.PreparedRepository `json:"repositories,omitempty"`
	Capabilities     workspaceCapabilities     `json:"capabilities"`
	Authority        []stow.Operation          `json:"authority"`
}

type workspaceCapabilities struct {
	Backend          stow.Backend              `json:"backend"`
	MaxBytes         int64                     `json:"max_bytes"`
	MaxObjects       int64                     `json:"max_objects"`
	Persistent       bool                      `json:"persistent"`
	Multipart        bool                      `json:"multipart"`
	Upstream         bool                      `json:"upstream"`
	CheckpointLimits checkpointRetentionLimits `json:"checkpoint_limits"`
	// RegistryBound is the workspace count limit that was applied and how much of it
	// this prepare used, so an agent can see its remaining headroom from the result
	// instead of learning the bound by being refused. Both are zero when no bound was
	// declared, which is the unbounded default.
	RegistryBound registryBound `json:"registry_bound"`
}

type checkpointRetentionLimits struct {
	MaxBytes int64 `json:"max_bytes"`
	MaxCount int64 `json:"max_count"`
}

type registryBound struct {
	MaxWorkspaces int64 `json:"max_workspaces"`
	InUse         int64 `json:"in_use"`
	// Remaining is what is left before the next prepare is refused. It is negative
	// never and equal to zero when the registry is exactly full, so a caller that
	// branches on it is branching on headroom rather than on a comparison it has to
	// reconstruct.
	Remaining int64 `json:"remaining"`
}

// registrySelection is what a caller asked for on the command line: a root, and
// optionally a partition inside it.
type registrySelection struct {
	dir  string
	team string
}

// resolve turns the selection into one directory. An override team replaces the
// flagged one, which is how a handoff document's partition wins over a flag that
// merely repeats it.
func (r registrySelection) resolve(overrideTeam string) (string, error) {
	team := r.team
	if overrideTeam != "" {
		team = overrideTeam
	}
	return stow.ResolveRegistryDir(r.dir, team)
}

// registryFlag registers the pair of flags every registry-scoped verb takes, and
// returns the reader that reports what was asked for.
//
// A team is a partition of the registry directory, so a verb that addresses a
// workspace without both flags can only reach the root, and a caller holding a
// team's workspace ID would have to spell the partition by hand — `teams/<name>`
// in a path, from a caller, in every script. That leaves the feature present only
// on the verbs where somebody remembered to add it, so the pair is registered in
// one place and every verb resolves it the same way.
func registryFlag(flags *flag.FlagSet) func() registrySelection {
	dir := flags.String("registry-dir", "", "Workspace registry directory")
	team := flags.String("team", "", "Team partition within the registry directory")
	return func() registrySelection { return registrySelection{dir: *dir, team: *team} }
}

type checkpointResult struct {
	Version     int      `json:"version"`
	ID          string   `json:"checkpoint_id"`
	WorkspaceID string   `json:"workspace_id"`
	ParentID    string   `json:"parent_checkpoint_id,omitempty"`
	Created     string   `json:"created"`
	Files       int64    `json:"files"`
	Bytes       int64    `json:"bytes"`
	Excluded    []string `json:"excluded_sensitive_paths,omitempty"`
}

// workspaceVerbs maps each subcommand to its implementation.
//
// It is a table rather than a switch because the verb list is now fifteen long
// and every one of them is a straight call: a switch grew the function's
// complexity by one per verb until it crossed the quality ratchet's ceiling of
// 15, and the ratchet was right to object, because a verb added for a new
// feature should not cost the dispatcher a point of branching. A table also
// makes the surface readable in one place, which is the thing a reader
// actually wants from a command with this many verbs.
var workspaceVerbs = map[string]func([]string) error{
	"adopt":      adoptHandoffCommand,
	"apply":      applyDeltaCommand,
	"checkpoint": checkpointWorkspaceCommand,
	"collect":    collectWorkspacesCommand,
	"delta":      deltaWorkspaceCommand,
	"destroy":    destroyWorkspaceCommand,
	"diff":       diffWorkspaceCommand,
	"export":     exportCheckpointCommand,
	"handoff":    handoffWorkspaceCommand,
	"import":     importCheckpointCommand,
	"list":       listWorkspacesCommand,
	"prepare":    prepareWorkspaceCommand,
	"preview":    previewCheckpointCommand,
	"prune":      pruneWorkspacesCommand,
	"restore":    restoreCheckpointCommand,
	"resume":     resumeWorkspaceCommand,
	"serve":      serveWorkspaceCommand,
}

// workspaceUsage is derived from the table rather than written out, so a verb
// cannot be added to the dispatcher without appearing in the usage line. It
// used to be a literal, which is how the two drifted apart before.
func workspaceUsage() string {
	return "usage: stow-s3 workspace <" + strings.Join(sortedWorkspaceVerbs(), "|") + ">"
}

// helpFlag is the set of spellings that mean "show me what I can do" rather than
// "run a verb". They are matched before the verb table is consulted, because a
// caller asking for help has not named a verb and the table cannot help them.
var helpFlag = map[string]bool{"-h": true, "--h": true, "-help": true, "--help": true, "help": true}

func workspaceCommand(args []string) error {
	// Ahead of the verb table: `workspace --version` names no verb.
	if versionRequested(args) {
		printVersion(os.Stdout, true)
		return nil
	}
	if len(args) == 0 {
		return errors.New(workspaceUsage())
	}
	if helpFlag[args[0]] {
		// Asking a fifteen-verb command for help is the first thing a stranger does,
		// and answering it with `unknown workspace command "--help"` is the worst
		// possible reply: it names the request as a mistake, and it does so without
		// printing the list that would have answered it. `stow-s3 serve --help`
		// prints usage and exits zero, so the same request to the two command groups
		// behaved differently for no reason a caller could see.
		//
		// The usage line is derived from the verb table, so it cannot fall behind it
		// the way a written-out list did.
		fmt.Println(workspaceUsage())
		for _, verb := range sortedWorkspaceVerbs() {
			fmt.Printf("  stow-s3 workspace %s --help\n", verb)
		}
		return nil
	}
	command, known := workspaceVerbs[args[0]]
	if !known {
		// An unknown verb is an error, but it is an error that should still say what
		// the alternatives are. Fifteen verbs is more than anyone remembers.
		return fmt.Errorf("unknown workspace command %q\n%s", args[0], workspaceUsage())
	}
	return command(args[1:])
}

// sortedWorkspaceVerbs lists the verb table in a stable order, so help output does
// not reshuffle between runs and a reader can find a verb by scanning down.
func sortedWorkspaceVerbs() []string {
	verbs := make([]string, 0, len(workspaceVerbs))
	for verb := range workspaceVerbs {
		verbs = append(verbs, verb)
	}
	sort.Strings(verbs)
	return verbs
}

func prepareWorkspaceCommand(args []string) error {
	flags := flag.NewFlagSet("workspace prepare", flag.ContinueOnError)
	manifestPath := flags.String("manifest", "", "Versioned JSON task manifest")
	if err := flags.Parse(args); err != nil {
		return err
	}
	if *manifestPath == "" {
		return errors.New("workspace prepare requires --manifest")
	}
	manifest, err := readWorkspaceManifest(*manifestPath)
	if err != nil {
		return err
	}
	prepared, err := prepareWorkspaceFromManifest(manifest)
	if err != nil {
		return err
	}
	defer prepared.Workspace.Close()
	result := makeWorkspaceResult(prepared.Workspace, prepared.SeededBytes, prepared.SeededObjects)
	result.Team = manifest.Team
	// Set here rather than in makeWorkspaceResult, which three other verbs share and
	// none of which has a bound: only a prepare that asked for one has a count.
	result.Capabilities.RegistryBound = registryBound{
		MaxWorkspaces: prepared.MaxWorkspaces,
		InUse:         prepared.RegistryEntries,
		Remaining:     prepared.MaxWorkspaces - prepared.RegistryEntries,
	}
	result.RegistryDir, err = stow.ResolveRegistryDir(manifest.RegistryDir, manifest.Team)
	if err != nil {
		return err
	}
	result.BaseIdentity = prepared.BaseIdentity
	result.Repositories = prepared.Repositories
	return writeWorkspaceJSON(result)
}

func readWorkspaceManifest(path string) (stow.WorkspaceTaskManifest, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return stow.WorkspaceTaskManifest{}, fmt.Errorf("read task manifest: %w", err)
	}
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	var manifest stow.WorkspaceTaskManifest
	if err := decoder.Decode(&manifest); err != nil {
		return manifest, fmt.Errorf("decode task manifest: %w", err)
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		return manifest, errors.New("task manifest must contain exactly one JSON value")
	}
	if manifest.Version != 1 {
		return manifest, fmt.Errorf("unsupported task manifest version %d (supported: 1)", manifest.Version)
	}
	if manifest.MaxBytes < 0 || manifest.MaxObjects < 0 || manifest.MaxCheckpointBytes < 0 ||
		manifest.MaxCheckpoints < 0 || manifest.MaxWorkspaces < 0 || manifest.TTLSeconds < 0 {
		return manifest, errors.New("task manifest limits and TTL must not be negative")
	}
	base, err := filepath.Abs(filepath.Dir(path))
	if err != nil {
		return manifest, err
	}
	resolveTaskManifestPaths(base, &manifest)
	return manifest, nil
}

func resolveTaskManifestPaths(base string, manifest *stow.WorkspaceTaskManifest) {
	manifest.Root = resolveManifestPath(base, manifest.Root)
	if manifest.RegistryDir != "" {
		manifest.RegistryDir = resolveManifestPath(base, manifest.RegistryDir)
	}
	for i := range manifest.Inputs {
		manifest.Inputs[i].Source = resolveManifestPath(base, manifest.Inputs[i].Source)
	}
	for i := range manifest.Repositories {
		manifest.Repositories[i].Source = resolveManifestPath(base, manifest.Repositories[i].Source)
	}
	if manifest.Root == base || manifest.Root == "." {
		manifest.Root = ""
	}
}

func prepareWorkspaceFromManifest(manifest stow.WorkspaceTaskManifest) (*stow.PreparedWorkspace, error) {
	if manifest.Root == "" {
		return nil, errors.New("task manifest root must name a new dedicated directory")
	}
	prepared, err := stow.PrepareWorkspace(stow.PrepareOptions{
		WorkspaceOptions: stow.WorkspaceOptions{
			Dir: manifest.Root, Bucket: manifest.Bucket,
			MaxBytes: manifest.MaxBytes, MaxObjects: manifest.MaxObjects,
			MaxCheckpointBytes: manifest.MaxCheckpointBytes, MaxCheckpoints: manifest.MaxCheckpoints,
			TTL:         time.Duration(manifest.TTLSeconds) * time.Second,
			RegistryDir: manifest.RegistryDir,
			Team:        manifest.Team,
		},
		WorkingDirectory:       manifest.WorkingDirectory,
		Inputs:                 manifest.Inputs,
		Repositories:           manifest.Repositories,
		IncludeSensitiveInputs: manifest.IncludeSensitiveInputs,
		MaxWorkspaces:          manifest.MaxWorkspaces,
	})
	if err != nil {
		return nil, err
	}
	return prepared, nil
}

func resumeWorkspaceCommand(args []string) error {
	flags := flag.NewFlagSet("workspace resume", flag.ContinueOnError)
	id := flags.String("id", "", "Workspace ID to resume")
	handoffPath := flags.String("handoff", "", "Read a workspace handoff reference")
	chosen := registryFlag(flags)
	if err := flags.Parse(args); err != nil {
		return err
	}
	selection := chosen()
	resolvedID, resolvedRegistryDir, checkpointID, resolvedTeam, err := resumeIdentifiers(*id, *handoffPath, selection)
	if err != nil {
		return err
	}
	if resolvedID == "" {
		return errors.New("workspace resume requires --id or --handoff")
	}
	// A handoff reference carries the partition it resolved to, so the team is not
	// re-applied to it; the directory it names is already the team's. Where the
	// caller named the flags instead, the selection is what gets resolved.
	registry := resolvedRegistryDir
	team := resolvedTeam
	if team == "" {
		team = selection.team
	}
	if registry == "" {
		if registry, err = selection.resolve(""); err != nil {
			return err
		}
	}
	ws, err := stow.ResumeWith(stow.WorkspaceOptions{RegistryDir: registry}, resolvedID)
	if err != nil {
		return err
	}
	defer ws.Close()
	if checkpointID != "" {
		manifest, err := stow.LoadCheckpoint(registry, checkpointID)
		if err != nil {
			return err
		}
		if manifest.WorkspaceID != ws.ID() {
			return errors.New("handoff checkpoint belongs to a different workspace")
		}
	}
	result := makeWorkspaceResult(ws, 0, 0)
	result.CheckpointID = checkpointID
	result.RegistryDir = registry
	result.Team = team
	return writeWorkspaceJSON(result)
}

func resumeIdentifiers(id, handoffPath string, selection registrySelection) (string, string, string, string, error) {
	if handoffPath == "" {
		return id, selection.dir, "", "", nil
	}
	if id != "" || selection.dir != "" || selection.team != "" {
		return "", "", "", "", errors.New("workspace resume accepts --handoff or --id/--registry-dir/--team, not both")
	}
	document, err := readHandoffDocument(handoffPath)
	if err != nil {
		return "", "", "", "", err
	}
	// The reference carries the partition it resolved to, so the team is reported
	// from the directory rather than re-derived from a flag.
	return document.WorkspaceID, document.RegistryDir, document.CheckpointID, "", nil
}

func makeWorkspaceResult(ws *stow.Workspace, seededBytes, seededObjects int64) workspaceResult {
	capabilities := ws.Capabilities()
	return workspaceResult{
		Version: 1, WorkspaceID: ws.ID(), Root: ws.Dir(),
		WorkingDirectory: ws.WorkingDirectory(), Bucket: ws.Bucket(),
		SeededBytes: seededBytes, SeededObjects: seededObjects,
		Capabilities: workspaceCapabilities{
			Backend: capabilities.Backend, MaxBytes: capabilities.MaxBytes,
			MaxObjects: capabilities.MaxObjects, Persistent: capabilities.Persistent,
			Multipart: capabilities.Multipart, Upstream: capabilities.Upstream,
			CheckpointLimits: checkpointRetentionLimits{MaxBytes: ws.MaxCheckpointBytes(), MaxCount: ws.MaxCheckpoints()},
		},
		Authority: ws.Authority().Operations(),
	}
}

func writeWorkspaceJSON(value interface{}) error { return writeWorkspaceJSONTo("", value) }

func writeWorkspaceJSONTo(path string, value interface{}) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	if path == "" {
		_, err = os.Stdout.Write(data)
		return err
	}
	return os.WriteFile(path, data, 0o600)
}
