package runtime

import (
	"errors"
	"fmt"
	"time"

	"github.com/chester-hill-solutions/stow-s3/internal/authority"
	"github.com/chester-hill-solutions/stow-s3/internal/policy"
	"github.com/chester-hill-solutions/stow-s3/internal/storage"
)

type Backend string

const (
	BackendMemory     Backend = "memory"
	BackendFilesystem Backend = "filesystem"
	BackendHost       Backend = "host"
	// BackendWorkspace is a directory a caller is working in, whose objects are
	// real files. Like the filesystem backend it is persistent, and like the
	// filesystem backend it requires a store to be supplied by the caller: a
	// workspace needs a directory, which Options does not carry. It is reached
	// through stow.OpenWorkspace rather than through Open, so there is no way to
	// ask for a workspace without saying where it is.
	BackendWorkspace Backend = "workspace"

	DefaultMaxBytes            int64 = 64 << 20
	DefaultMaxObjects          int64 = 10_000
	DefaultMaxMultipartUploads int64 = 1024

	// UnlimitedBytes and UnlimitedObjects disable quota enforcement. The
	// embedded profile applies DefaultMaxBytes/DefaultMaxObjects; a long-lived
	// native server keeps its existing unbounded behavior unless an operator
	// opts in, and a scoped agent session passes explicit limits.
	UnlimitedBytes   int64 = 1<<63 - 1
	UnlimitedObjects int64 = 1<<63 - 1
)

var (
	ErrClosed                   = errors.New("runtime is closed")
	ErrQuotaExceeded            = errors.New("runtime quota exceeded")
	ErrUnsupportedBackend       = errors.New("unsupported runtime backend")
	ErrInvalidListLimit         = errors.New("runtime list limit must not be negative")
	ErrExternalResetUnsupported = errors.New("runtime reset is unsupported for an externally managed store")
	// ErrResourceUnresolved is for an operation addressed by a handle whose
	// resource this instance cannot establish. It only ever appears when a
	// policy is in force, because without one there is nothing to evaluate.
	ErrResourceUnresolved = errors.New("runtime cannot resolve the resource this operation addresses")

	// The store said so, not the runtime: MultipartStore is optional, and the
	// absence has one vocabulary wherever it is discovered.
	ErrMultipartUnsupported = storage.ErrMultipartUnsupported
)

// isKnownBackend reports whether the runtime understands a backend name. An
// unrecognised one is refused rather than treated as memory, because a caller
// who asked for durable bytes must not be handed volatile ones.
func isKnownBackend(backend Backend) bool {
	switch backend {
	case BackendMemory, BackendFilesystem, BackendWorkspace, BackendHost:
		return true
	default:
		return false
	}
}

// isPersistentBackend reports whether a backend keeps objects across a reopen.
// It is the capability a host asks about, and it is why the two persistent
// backends need a store supplied rather than constructed from Options.
//
// It is deliberately unexported: a host is handed runtime.Capabilities rather
// than re-deriving the answer, and a second derivation is a second opinion.
func isPersistentBackend(backend Backend) bool {
	return backend == BackendFilesystem || backend == BackendWorkspace || backend == BackendHost
}

// normalizeOptions validates a backend choice and applies the quota defaults.
// Memory needs no store; the two persistent backends do, which is why they are
// reachable only from OpenWithStore. See isKnownBackend in types.go.
func normalizeOptions(options Options, boundStore bool) (Options, error) {
	if options.Backend == "" {
		options.Backend = BackendMemory
	}
	if boundStore {
		if !isKnownBackend(options.Backend) {
			return Options{}, ErrUnsupportedBackend
		}
	} else if options.Backend != BackendMemory {
		return Options{}, ErrUnsupportedBackend
	}
	if options.MaxBytes < 0 || options.MaxObjects < 0 || options.MaxMultipartUploads < 0 {
		return Options{}, fmt.Errorf("runtime quotas must not be negative")
	}
	if options.MaxBytes == 0 {
		options.MaxBytes = DefaultMaxBytes
	}
	if options.MaxObjects == 0 {
		options.MaxObjects = DefaultMaxObjects
	}
	if options.MaxMultipartUploads == 0 {
		options.MaxMultipartUploads = DefaultMaxMultipartUploads
	}
	return options, nil
}

type Options struct {
	Backend             Backend
	MaxBytes            int64
	MaxObjects          int64
	MaxMultipartUploads int64

	// Authority is what this environment permits. It is enforced here, below
	// every interface, so that S3 and a native caller cannot be granted
	// different things.
	//
	// A nil pointer means every operation, and that is the default on purpose:
	// it is what an Instance opened without one has always permitted, so adding
	// the field changes no existing behaviour. Pass &authority.None() to permit
	// nothing. The pointer is what makes those two states distinguishable — a
	// bare Authority cannot tell "unset" from "explicitly empty".
	Authority *authority.Authority

	// Policy narrows Authority to the resources a selector covers, so a caller
	// with full authority can still be confined to part of a bucket. It is
	// intersected with Authority rather than replacing it: a policy cannot grant
	// what the environment does not have, and one written wider than the
	// environment is refused rather than clipped silently.
	//
	// It is a policy.Source, consulted per decision rather than read once. Use
	// policy.Fixed for a policy that does not change. A nil value means no policy is
	// consulted, which is what an Instance opened without one has always done.
	Policy policy.Source
}

type Capabilities struct {
	Backend             Backend
	MaxBytes            int64
	MaxObjects          int64
	MaxMultipartUploads int64
	Persistent          bool
	Multipart           bool
	Upstream            bool
}

type Usage struct {
	Bytes   int64
	Objects int64
}

type Bucket struct {
	Name         string
	CreationDate time.Time
}

type Object struct {
	Bucket            string
	Key               string
	Data              []byte
	Size              int64
	ETag              string
	VersionID         string
	ContentType       string
	Metadata          map[string]string
	LastModified      time.Time
	ChecksumAlgorithm string
	ChecksumValue     string
}

type PutOptions struct {
	computeChecksum   bool
	ContentType       string
	Metadata          map[string]string
	ChecksumAlgorithm string
	ChecksumValue     string
	IfMatch           string
	IfNoneMatch       string
	guard             *storage.WriteGuard
	requestKey        string
}

type ObjectPage struct {
	Objects        []Object
	CommonPrefixes []string
	Truncated      bool
	Cursor         string
	NextCursor     string
	KeyCount       int
}

type ListOptions struct {
	Prefix     string
	Cursor     string
	Limit      int
	Delimiter  string
	StartAfter string
}
