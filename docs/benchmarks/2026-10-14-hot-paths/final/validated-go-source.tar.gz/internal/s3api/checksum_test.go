package s3api_test

import (
	"encoding/base64"
	"io"
	"net/http"
	"strings"
	"testing"

	"github.com/chester-hill-solutions/stow-s3/internal/storage"
)

func TestPutObjectChecksumAlgorithms(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()

	create := func(bucket string) {
		t.Helper()
		req, _ := http.NewRequest(http.MethodPut, ts.URL+"/"+bucket, nil)
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("create bucket status = %d", resp.StatusCode)
		}
	}
	create("checksum-bucket")
	body := "checksum-body"
	for _, algorithm := range []string{"CRC32", "CRC32C", "CRC64NVME", "SHA1", "SHA256"} {
		t.Run(algorithm, func(t *testing.T) {
			value, err := storage.ComputeChecksum(algorithm, []byte(body))
			if err != nil {
				t.Fatal(err)
			}
			key := strings.ToLower(algorithm)
			req, _ := http.NewRequest(http.MethodPut, ts.URL+"/checksum-bucket/"+key, strings.NewReader(body))
			req.Header.Set("x-amz-checksum-"+strings.ToLower(algorithm), value)
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				t.Fatal(err)
			}
			defer resp.Body.Close()
			if resp.StatusCode != http.StatusOK {
				payload, _ := io.ReadAll(resp.Body)
				t.Fatalf("status = %d: %s", resp.StatusCode, payload)
			}
			if got := resp.Header.Get("x-amz-checksum-" + strings.ToLower(algorithm)); got != value {
				t.Fatalf("response checksum = %q, want %q", got, value)
			}
		})
	}
}

func TestPutObjectRejectsBadAndUnknownChecksums(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()
	req, _ := http.NewRequest(http.MethodPut, ts.URL+"/checksum-bucket", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()

	bad := base64.StdEncoding.EncodeToString([]byte{0, 0, 0, 0})
	for _, testCase := range []struct {
		name   string
		header string
		value  string
	}{
		{name: "bad NVME digest", header: "x-amz-checksum-crc64nvme", value: "AAAAAAAAAAA="},
		{name: "bad digest", header: "x-amz-checksum-crc32", value: bad},
		{name: "unknown algorithm", header: "x-amz-checksum-sha512", value: bad},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			req, _ := http.NewRequest(http.MethodPut, ts.URL+"/checksum-bucket/"+testCase.name, strings.NewReader("body"))
			req.Header.Set(testCase.header, testCase.value)
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				t.Fatal(err)
			}
			defer resp.Body.Close()
			if resp.StatusCode != http.StatusBadRequest {
				t.Fatalf("status = %d, want 400", resp.StatusCode)
			}
		})
	}
}

func TestCRC64MultipartDeclarationIsExplicitlyUnsupported(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()
	req, _ := http.NewRequest(http.MethodPut, ts.URL+"/checksum-bucket", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	req, _ = http.NewRequest(http.MethodPost, ts.URL+"/checksum-bucket/object?uploads", nil)
	req.Header.Set("x-amz-checksum-algorithm", "CRC64NVME")
	req.Header.Set("x-amz-checksum-type", "FULL_OBJECT")
	resp, err = http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusNotImplemented {
		body, _ := io.ReadAll(resp.Body)
		t.Fatalf("status=%d body=%s", resp.StatusCode, body)
	}
}

func TestPutComputesRequestedChecksumWithoutSuppliedValue(t *testing.T) {
	ts := newTestServer(t)
	defer ts.Close()
	request, _ := http.NewRequest(http.MethodPut, ts.URL+"/auto-checksum", nil)
	response, err := http.DefaultClient.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	body := "owned checksum payload"
	request, _ = http.NewRequest(http.MethodPut, ts.URL+"/auto-checksum/key", strings.NewReader(body))
	request.Header.Set("x-amz-sdk-checksum-algorithm", "CRC32C")
	response, err = http.DefaultClient.Do(request)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	expected, err := storage.ComputeChecksum("CRC32C", []byte(body))
	if err != nil {
		t.Fatal(err)
	}
	if response.StatusCode != http.StatusOK || response.Header.Get("x-amz-checksum-crc32c") != expected {
		t.Fatalf("status=%d checksum=%q", response.StatusCode, response.Header.Get("x-amz-checksum-crc32c"))
	}
}
