package storage

import (
	"context"
	"io"
)

// Store is the core object storage interface: the object model, and nothing else.
//
// Multipart is deliberately not a member. It is how one protocol happens to
// stream an object larger than memory, and requiring it of every store put that
// protocol's shape into the object model. It is the optional interface below.
type Store interface {
	CreateBucket(ctx context.Context, name string) error
	DeleteBucket(ctx context.Context, name string) error
	HeadBucket(ctx context.Context, name string) (*BucketInfo, error)
	ListBuckets(ctx context.Context) ([]BucketInfo, error)

	PutObject(ctx context.Context, bucket, key string, body io.Reader, opts PutOptions) (*ObjectMeta, error)
	GetObject(ctx context.Context, bucket, key string) (io.ReadCloser, *ObjectMeta, error)
	HeadObject(ctx context.Context, bucket, key string) (*ObjectMeta, error)
	DeleteObject(ctx context.Context, bucket, key string) error
	// DeleteObjects deletes each key and returns the keys it confirmed deleted, in
	// request order.
	//
	// A key that was not there counts as confirmed: S3 deletes idempotently and
	// reports a missing key as deleted rather than as an error, so it appears in
	// the returned slice and in the response's Deleted entries. Only a key whose
	// delete actually failed is left out.
	//
	// On failure it returns the keys confirmed before the failure alongside the
	// error, so a caller retrying the remainder can skip what already succeeded.
	DeleteObjects(ctx context.Context, bucket string, keys []string) ([]string, error)
	// CopyObject publishes the destination key from exactly one version, so a concurrent
	// write cannot be half-copied.
	CopyObject(ctx context.Context, srcBucket, srcKey, dstBucket, dstKey string) (*ObjectMeta, error)
	ListObjectsV2(ctx context.Context, bucket string, opts ListOptions) (*ListResult, error)

	Close() error
}

// MultipartStore is the optional extension: a store that can stream an object
// larger than memory.
//
// It is whole rather than write-only because a consumer that reconciles in-flight
// uploads when it opens must be able to ask what is in flight. A write-only
// implementation would force the reader to invent that answer.
type MultipartStore interface {
	CreateMultipartUpload(ctx context.Context, bucket, key string, opts MultipartOptions) (*MultipartUpload, error)
	GetMultipartUpload(ctx context.Context, uploadID string) (*MultipartUpload, error)
	UploadPart(ctx context.Context, uploadID string, partNumber int, body io.Reader) (*PartInfo, error)
	CompleteMultipartUpload(ctx context.Context, uploadID string, parts []PartInfo) (*ObjectMeta, error)
	AbortMultipartUpload(ctx context.Context, uploadID string) error
	ListParts(ctx context.Context, uploadID string) ([]PartInfo, error)
	ValidateMultipartUpload(ctx context.Context, uploadID, bucket, key string) error
	ListMultipartUploads(ctx context.Context, bucket string, opts MultipartListOptions) (*MultipartListResult, error)
}

// CopyOptions carries the preconditions a caller may attach to the source of a
// copy.
//
// They are the source-side twin of PutOptions.IfMatch and IfNoneMatch, and they
// mean the same thing: the copy is refused unless the source version being
// copied is the one the caller asked for.
type CopyOptions struct {
	SourceIfMatch     string
	SourceIfNoneMatch string
}

// CopyRequest names a copy: which object, to where, under which conditions.
//
// It is a struct rather than five positional parameters because the parameters
// come in pairs — a bucket and a key are not separable — and a signature that
// takes two adjacent strings invites swapping them. A copy that swapped its
// source and destination would still typecheck.
type CopyRequest struct {
	SourceBucket string
	SourceKey    string
	DestBucket   string
	DestKey      string
	Options      CopyOptions
}

// ConditionalCopyStore is the optional extension: a copy that can refuse to
// publish anything unless the source version satisfies the caller's conditions.
//
// It is optional, and separately so, because this is the one case where two
// implementations can differ in a way a client can observe and cannot fix. A
// caller that checked a condition itself and then called CopyObject has asked
// "copy the version whose ETag I read"; a store that re-reads the source cannot
// honour that, because between the check and the copy the source may have moved
// on, and the copy would then publish a version the caller never asked about and
// never saw. So a store that implements this evaluates the conditions against
// the same captured version whose bytes it copies, and a store that does not
// implement it can only promise that the copy is internally coherent.
type ConditionalCopyStore interface {
	CopyObjectCond(ctx context.Context, req CopyRequest) (*ObjectMeta, error)
}

// UsageRevisionStore settles pending publication before reporting managed revisions.
// Unknown publication returns its stable revision with ErrSaveRequestUnknown.
type UsageRevisionStore interface {
	UsageRevision(ctx context.Context) (uint64, error)
}

// PutChecksumStore computes requested checksums on owned bytes before publication.
type PutChecksumStore interface {
	ComputesPutChecksums() bool
}

type ObjectUsage struct{ Bytes, Objects int64 }

// ObjectUsageStore scans one bucket's object accounting without paginated rescans.
type ObjectUsageStore interface {
	ScanObjectUsage(ctx context.Context, bucket string) (ObjectUsage, error)
}
